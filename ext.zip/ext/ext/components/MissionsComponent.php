<?php

class MissionsComponent {
    public static function render($missionData, $usid, $Translate) {
        ob_start();
        ?>
        <?php
        $hasMissions = !empty($missionData);
        $groupClasses = 'battlePassGroupTasks';
        if (!$hasMissions) {
            $groupClasses .= ' no-missions';
        }
        ?>
        <article class="<?php echo $groupClasses; ?>">
            <?php if ($hasMissions): ?>
                <div class="battlePassHeader items-center">
                    <span class="battlePassTitle flex justify-center items-center gap-1.5">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24"
                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round" class="lucide lucide-logs">
                            <path d="M13 12h8"></path>
                            <path d="M13 18h8"></path>
                            <path d="M13 6h8"></path>
                            <path d="M3 12h1"></path>
                            <path d="M3 18h1"></path>
                            <path d="M3 6h1"></path>
                            <path d="M8 12h1"></path>
                            <path d="M8 18h1"></path>
                            <path d="M8 6h1"></path>
                        </svg>
                        <?= $Translate->get_translate_module_phrase('module_page_battlepass', '_PassMissions') ?>
                    </span>
                </div>
            <?php endif; ?>
            <ul class="battlePassTasks">
                <?php if ($hasMissions): ?>
                    <?php foreach ($missionData as $mission): ?>
                        <li class="battlePassTask">
                            <div class="battlePassHeader">
                                <span class="battlePassTime" data-expires="<?php echo $mission['expires']; ?>"
                                    data-progress="<?php echo $mission['progress']; ?>"
                                    data-nedeed="<?php echo $mission['nedeed']; ?>">
                                    <?php if ($mission['progress'] >= $mission['nedeed']) {
                                        echo '<span class="completed">შესრულებულია</span>';
                                    } else {
                                        $currentTime = time();
                                        $expiresTime = (int) $mission['expires'];
                                        $timeLeft = $expiresTime - $currentTime;
                                        if ($timeLeft > 0) {
                                            $hours = floor($timeLeft / 3600);
                                            $minutes = floor(($timeLeft % 3600) / 60);
                                            $seconds = $timeLeft % 60;
                                            $timeLeftFormatted = sprintf("%02d:%02d:%02d", $hours, $minutes, $seconds);
                                            echo $timeLeftFormatted;
                                        } else {
                                            echo "00:00:00";
                                        }
                                    } ?>
                                </span>
                                <?php if ($mission['exp'] > 0): ?>
                                    <span class="battlePassExp">
                                        <span
                                            style="color: var(--default-text-color); padding: 2px 10px; border-radius: 12px; background-color: var(--span-color); font-size: 12px; font-weight: 700;">
                                            +<?php echo $mission['exp']; ?> EXP
                                        </span>
                                    </span>
                                <?php endif; ?>

                                <?php if ($mission['stars'] > 0): ?>
                                    <span
                                        style="color: var(--default-text-color); padding: 2px 10px; border-radius: 12px; background-color: var(--span-color); font-size: 12px; font-weight: 700;">
                                        +<?php echo $mission['stars']; ?>
                                        <svg width="14px" height="14px" viewBox="0 0 24 24" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">

                                            <path
                                                d="M10.0802 7.89712C11.1568 5.96571 11.6952 5 12.5 5C13.3048 5 13.8432 5.96571 14.9198 7.89712L15.1984 8.3968C15.5043 8.94564 15.6573 9.22007 15.8958 9.40114C16.1343 9.5822 16.4314 9.64942 17.0255 9.78384L17.5664 9.90622C19.6571 10.3793 20.7025 10.6158 20.9512 11.4156C21.1999 12.2153 20.4872 13.0487 19.0619 14.7154L18.6932 15.1466C18.2881 15.6203 18.0856 15.8571 17.9945 16.1501C17.9034 16.443 17.934 16.759 17.9953 17.3909L18.051 17.9662C18.2665 20.19 18.3742 21.3019 17.7231 21.7962C17.072 22.2905 16.0932 21.8398 14.1357 20.9385L13.6292 20.7053C13.073 20.4492 12.7948 20.3211 12.5 20.3211C12.2052 20.3211 11.927 20.4492 11.3708 20.7053L10.8643 20.9385C8.90677 21.8398 7.928 22.2905 7.27688 21.7962C6.62575 21.3019 6.7335 20.19 6.94899 17.9662L7.00474 17.3909C7.06597 16.759 7.09659 16.443 7.00548 16.1501C6.91438 15.8571 6.71186 15.6203 6.30683 15.1466L5.93808 14.7154C4.51276 13.0487 3.8001 12.2153 4.04881 11.4156C4.29751 10.6158 5.34288 10.3793 7.43361 9.90622L7.9745 9.78384C8.56862 9.64942 8.86568 9.5822 9.1042 9.40114C9.34272 9.22007 9.4957 8.94565 9.80165 8.3968L10.0802 7.89712Z"
                                                fill="var(--default-text-color)"></path>
                                            <path
                                                d="M4.86752 2.50058C4.89751 2.3948 5.08528 2.39416 5.11598 2.49974C5.25618 2.98185 5.51616 3.69447 5.90928 4.08495C6.30241 4.47543 7.01676 4.73058 7.49981 4.86752C7.6056 4.89751 7.60623 5.08528 7.50065 5.11598C7.01854 5.25618 6.30592 5.51616 5.91545 5.90928C5.52497 6.30241 5.26981 7.01676 5.13287 7.49981C5.10288 7.6056 4.91511 7.60623 4.88441 7.50065C4.74421 7.01854 4.48424 6.30592 4.09111 5.91545C3.69798 5.52497 2.98363 5.26981 2.50058 5.13287C2.3948 5.10288 2.39416 4.91511 2.49974 4.88441C2.98185 4.74421 3.69447 4.48424 4.08495 4.09111C4.47543 3.69798 4.73058 2.98363 4.86752 2.50058Z"
                                                fill="var(--default-text-color)"></path>
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M19 3.25C19.4142 3.25 19.75 3.58579 19.75 4V4.25H20C20.4142 4.25 20.75 4.58579 20.75 5C20.75 5.41421 20.4142 5.75 20 5.75H19.75V6C19.75 6.41421 19.4142 6.75 19 6.75C18.5858 6.75 18.25 6.41421 18.25 6V5.75H18C17.5858 5.75 17.25 5.41421 17.25 5C17.25 4.58579 17.5858 4.25 18 4.25H18.25V4C18.25 3.58579 18.5858 3.25 19 3.25Z"
                                                fill="var(--default-text-color)"></path>
                                        </svg>
                                    </span>
                                <?php endif; ?>

                                <?php if ($mission['paid_pass']): ?>
                                    <span
                                        style="color: var(--default-text-color); padding: 2px 10px; border-radius: 12px; background-color: var(--span-color); font-size: 12px; font-weight: 700;">
                                        <?= htmlspecialchars($Translate->get_translate_module_phrase('module_page_battlepass', '_PayMission')) ?>
                                        <svg width="14px" height="14px" viewBox="0 0 24 24" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">

                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M20.4105 9.86058C20.3559 9.8571 20.2964 9.85712 20.2348 9.85715L20.2194 9.85715H17.8015C15.8086 9.85715 14.1033 11.4382 14.1033 13.5C14.1033 15.5618 15.8086 17.1429 17.8015 17.1429H20.2194L20.2348 17.1429C20.2964 17.1429 20.3559 17.1429 20.4105 17.1394C21.22 17.0879 21.9359 16.4495 21.9961 15.5577C22.0001 15.4992 22 15.4362 22 15.3778L22 15.3619V11.6381L22 11.6222C22 11.5638 22.0001 11.5008 21.9961 11.4423C21.9359 10.5506 21.22 9.91209 20.4105 9.86058ZM17.5872 14.4714C18.1002 14.4714 18.5162 14.0365 18.5162 13.5C18.5162 12.9635 18.1002 12.5286 17.5872 12.5286C17.0741 12.5286 16.6581 12.9635 16.6581 13.5C16.6581 14.0365 17.0741 14.4714 17.5872 14.4714Z"
                                                fill="var(--default-text-color) "></path>
                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                d="M20.2341 18.6C20.3778 18.5963 20.4866 18.7304 20.4476 18.8699C20.2541 19.562 19.947 20.1518 19.4542 20.6485C18.7329 21.3755 17.8183 21.6981 16.6882 21.8512C15.5902 22 14.1872 22 12.4158 22H10.3794C8.60803 22 7.20501 22 6.10697 21.8512C4.97692 21.6981 4.06227 21.3755 3.34096 20.6485C2.61964 19.9215 2.29953 18.9997 2.1476 17.8608C1.99997 16.7541 1.99999 15.3401 2 13.5548V13.4452C1.99998 11.6599 1.99997 10.2459 2.1476 9.13924C2.29953 8.00031 2.61964 7.07848 3.34096 6.35149C4.06227 5.62451 4.97692 5.30188 6.10697 5.14876C7.205 4.99997 8.60802 4.99999 10.3794 5L12.4158 5C14.1872 4.99998 15.5902 4.99997 16.6882 5.14876C17.8183 5.30188 18.7329 5.62451 19.4542 6.35149C19.947 6.84817 20.2541 7.43804 20.4476 8.13012C20.4866 8.26959 20.3778 8.40376 20.2341 8.4L17.8015 8.40001C15.0673 8.40001 12.6575 10.5769 12.6575 13.5C12.6575 16.4231 15.0673 18.6 17.8015 18.6L20.2341 18.6ZM5.61446 8.88572C5.21522 8.88572 4.89157 9.21191 4.89157 9.61429C4.89157 10.0167 5.21522 10.3429 5.61446 10.3429H9.46988C9.86912 10.3429 10.1928 10.0167 10.1928 9.61429C10.1928 9.21191 9.86912 8.88572 9.46988 8.88572H5.61446Z"
                                                fill="var(--default-text-color) "></path>
                                            <path
                                                d="M7.77668 4.02439L9.73549 2.58126C10.7874 1.80625 12.2126 1.80625 13.2645 2.58126L15.2336 4.03197C14.4103 3.99995 13.4909 3.99998 12.4829 4H10.3123C9.39123 3.99998 8.5441 3.99996 7.77668 4.02439Z"
                                                fill="var(--default-text-color) "></path>
                                        </svg>
                                    </span>
                                <?php endif; ?>
                            </div>
                            <span class="battlePassDescription"><?php echo $mission['description']; ?></span>
                            <div class="battlePassLineBackground">
                                <div class="battlePassLineFill"
                                    style="width: <?php echo ($mission['progress'] / $mission['nedeed']) * 100; ?>%; max-width: 100%;">
                                </div>
                            </div>
                            <span class="battlePassCount"><?php echo $mission['progress']; ?>/<?php echo $mission['nedeed']; ?></span>
                        </li>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="missions-loading">
                        <div class="spinner"></div>
                        <p><?= $Translate->get_translate_module_phrase('module_page_battlepass', '_Loading') ?></p>
                    </div>
                <?php endif; ?>
            </ul>

            <script>
                function updateTimers() {
                    const timers = document.querySelectorAll('.battlePassTime');
                    const currentTime = Math.floor(Date.now() / 1000);

                    timers.forEach(timer => {
                        const progress = parseInt(timer.getAttribute('data-progress'));
                        const nedeed = parseInt(timer.getAttribute('data-nedeed'));

                        if (progress >= nedeed) {
                            const completedSpan = timer.querySelector('.completed');
                            if (!completedSpan) {
                                timer.innerHTML = '<span class="completed">შესრულებულია</span>';
                            }
                            return;
                        }

                        const expiresTime = parseInt(timer.getAttribute('data-expires'));

                        let timeLeft = expiresTime - currentTime;

                        if (timeLeft < 0) {
                            timeLeft = 0;
                        }

                        const hours = Math.floor(timeLeft / 3600);
                        const minutes = Math.floor((timeLeft % 3600) / 60);
                        const seconds = timeLeft % 60;

                        const timeLeftFormatted = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

                        timer.textContent = timeLeftFormatted;
                    });
                }

                setInterval(updateTimers, 1000);

                updateTimers();
            </script>
        </article>
        <?php
        return ob_get_clean();
    }
}