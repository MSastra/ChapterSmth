<?php

class TopPlayersComponent {
    public static function render($topPlayers, $nicknames, $Translate) {
        ob_start();
        ?>
        <article class="battlePassGroupExp">
            <span class="battlePassTitle"><?= $Translate->get_translate_module_phrase('module_page_battlepass', '_PassTop100') ?></span>

            <div class="battlePassScrollable">
                <?php foreach ($topPlayers as $index => $player): ?>
                    <?php $highlightStyle = $index < 3 ? 'style="color: var(--span-color);"' : ''; ?>
                    <a href="/profiles/<?php echo htmlspecialchars($player['steamid']); ?>" class="battlePassItemUs">
                        <ul class="battlePassTop">
                            <li class="battlestg">
                                <span class="battlePassNumber battlePassActive" <?php echo $highlightStyle; ?>>
                                    #<?php echo $index + 1; ?>
                                </span>
                                <div class="overflow-hidden max-w-[240px]">
                                    <div class="userRoot max-w-[240px]">
                                        <?php
                                        $domain = $_SERVER['REQUEST_SCHEME'] . '://' . $_SERVER['HTTP_HOST'];
                                        $filePath = $_SERVER['DOCUMENT_ROOT'] . "/storage/cache/img/avatars/" . htmlspecialchars($player['steamid']) . ".json";
                                        $avatarData = file_exists($filePath) ? json_decode(file_get_contents($filePath), true) : null;
                                        $avatarUrl = $avatarData['avatar'] ?? $domain . '/app/modules/module_page_battlepass/assets/img/NoImage.webp';
                                        $nickname = $avatarData['name'] ?? 'Unknown';
                                        ?>

                                        <img class="user__avatarbp" src="<?php echo htmlspecialchars($avatarUrl); ?>" alt="" loading="eager" class="userAvatar">

                                        <div class="userBlock">
                                            <div class="userNickBlock">
                                                <span class="userNick">
                                                    <?php
                                                    $steamid = $player['steamid'];
                                                    $nickname = $nicknames[$steamid] ?? $nickname;
                                                    echo htmlspecialchars($nickname);
                                                    ?>
                                                </span>
                                                <p class="misstop">
                                                    <?php echo htmlspecialchars($player['exp']); ?> EXP
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </a>
                <?php endforeach; ?>
            </div>
        </article>
        <?php
        return ob_get_clean();
    }
}