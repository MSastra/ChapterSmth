<?php

class AuthMessageComponent {
    public static function render($Translate) {
        ob_start();
        ?>
        <div class="error_contentauth">
            <div class="error_texts_block_bp">
                <div class="error_oops">
                    <?= htmlspecialchars($Translate->get_translate_module_phrase('module_page_battlepass', '_AuthMsg')) ?>
                    <a href="?auth=login">
                        <button class="auth_user_btn">
                            <?= $Translate->get_translate_module_phrase('module_page_battlepass', '_Auth') ?>
                        </button>
                    </a>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}