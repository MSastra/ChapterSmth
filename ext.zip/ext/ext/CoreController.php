<?php

require_once __DIR__ . '/models/BattlepassModel.php';
require_once __DIR__ . '/helpers/UserHelper.php';
require_once __DIR__ . '/helpers/BattlepassHelper.php';
require_once __DIR__ . '/helpers/UrlHelper.php';
require_once __DIR__ . '/components/UserInfoComponent.php';
require_once __DIR__ . '/components/TopPlayersComponent.php';
require_once __DIR__ . '/components/MissionsComponent.php';
require_once __DIR__ . '/components/LevelsComponent.php';
require_once __DIR__ . '/components/SeasonBannerComponent.php';
require_once __DIR__ . '/components/AuthMessageComponent.php';

class CoreController {
    private $Db;
    private $General;
    private $Translate;
    private $Modules;
    private $server_group;
    private $res_data = [];
    private $model;

    public function __construct($Db, $General, $Translate, $Modules) {
        $this->Db = $Db;
        $this->General = $General;
        $this->Translate = $Translate;
        $this->Modules = $Modules;
        
        $this->initialize();
    }
    
    private function initialize() {
        $this->General->get_default_url_section('filter', 'value', array('value', 'level', 'exp', 'stars', 'season_id', 'paid', 'server_id'));
        
        $this->server_group = isset($_GET['server_group']) ? (int) $_GET['server_group'] : 0;
        if ($this->server_group >= $this->Db->table_statistics_count) {
            echo 'სერვერი არ არსებობს'; 
            $this->server_group = 0;
        }
        
        for ($d = 0; $d < $this->Db->table_count['Core']; $d++) {
            $this->res_data[] = [
                'statistics' => 'Core',
                'name_servers' => $this->Db->db_data['Core'][$d]['name'],
                'mod' => $this->Db->db_data['Core'][$d]['mod'],
                'USER_ID' => $this->Db->db_data['Core'][$d]['USER_ID'],
                'data_db' => $this->Db->db_data['Core'][$d]['DB_num'],
                'data_servers' => $this->Db->db_data['Core'][$d]['Table']
            ];
        }
        
        $this->model = new BattlepassModel($this->Db, $this->server_group, $this->res_data);
    }
    
    public function getPageData($page_num, $players_per_page) {
        $users = $this->model->getUsersData($page_num, $players_per_page, $_SESSION['filter']);
        $top_players = $this->model->getTopPlayers();
        $steamids = array_column($top_players, 'steamid');
        $nicknames = UserHelper::getNicknames($steamids);
        $user = $this->model->getUserData($_SESSION['steamid64'] ?? '');
        $usid = $user[0]['id'] ?? null;
        $rewards = $this->model->getRewards();
        $rewardData = BattlepassHelper::processRewardsData($rewards);
        $currentLevel = !empty($user) ? $user[0]['level'] : 0;
        $nextLevel = $currentLevel + 1;
        
        if (isset($rewardData[$nextLevel])) {
            $explvl = $rewardData[$nextLevel]['explvl'];
        } else {
            $explvl = 0;
        }
        
        $takenLevelsData = $this->model->getTakenLevels($usid);
        $takenLevels = array_column($takenLevelsData, 'level_id');
        $missions = $this->model->getMissions($usid);
        $missionIdentifiers = array_unique(array_column($missions, 'mission'));
        $tasks = $this->model->getTasks($missionIdentifiers);
        $missionData = BattlepassHelper::processMissionsData($missions, $tasks);
        $seasons = $this->model->getSeasons();
        $seasonData = BattlepassHelper::processSeasonData($seasons);
        $this->setPageTitle();
        
        return [
            'users' => $users,
            'top_players' => $top_players,
            'nicknames' => $nicknames,
            'user' => $user,
            'usid' => $usid,
            'rewardData' => $rewardData,
            'currentLevel' => $currentLevel,
            'explvl' => $explvl,
            'takenLevels' => $takenLevels,
            'missionData' => $missionData,
            'nameseason' => $seasonData['name'],
            'daysLeft' => $seasonData['days_left']
        ];
    }
    
    public function renderPage($data) {
        ob_start();
        ?>
                <div class="card" style="box-shadow:0 0 10px rgb(0 0 0 / 50%); background: transparent; overflow: hidden;">
                    <?php 
                    echo SeasonBannerComponent::render($data['nameseason'], $data['currentLevel'], $data['explvl'], $data['daysLeft'], $this->Translate);
                    
                    if (empty($_SESSION['steamid64'])): 
                        echo SeasonBannerComponent::close();
                    else: 
                        echo UserInfoComponent::render($data['user'], $data['currentLevel'], $data['explvl'], $this->Translate);
                        echo SeasonBannerComponent::close();
                    endif;
                    ?>
                    
                    <section class="battlePassFooter">
                        <?php
                        echo TopPlayersComponent::render($data['top_players'], $data['nicknames'], $this->Translate);
                        
                        if (empty($_SESSION['steamid64'])): 
                            echo AuthMessageComponent::render($this->Translate);
                        else:
                            echo MissionsComponent::render($data['missionData'], $data['usid'], $this->Translate);
                        endif;
                        ?>
                    </section>
                    
                    <?php
                    if (!empty($data['rewardData'])) {
                        echo LevelsComponent::render(
                            $data['rewardData'], 
                            $data['currentLevel'], 
                            $data['takenLevels'], 
                            $data['user'], 
                            $this->Translate
                        );
                    }
                    ?>
                </div>
        <?php
        return ob_get_clean();
    }
    
    public function setPageTitle() {
        $this->Modules->set_page_title(
            $this->Translate->get_translate_module_phrase('module_page_battlepass', '_PassName') . ' | ' . $this->General->arr_general['short_name']
        );
    }
    
    public function getSiteUrl() {
        $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        return $protocol . '://' . $host . '/';
    }
}